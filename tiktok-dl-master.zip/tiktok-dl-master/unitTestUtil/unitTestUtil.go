package unittestutil

import (
	"testing"
)

// TestUtil - Utility for testing
type TestUtil struct {
	T *testing.T
}
